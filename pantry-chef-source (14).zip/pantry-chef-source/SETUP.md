# Pantry Chef source code

## Run locally

Install Node.js 22+ and Bun, then open a terminal in this extracted folder:

```sh
bun install
bun run dev
```

Open the local address printed in the terminal.

## AI configuration

Recipe and meal-plan generation require a valid Lovable AI Gateway API key. Set `LOVABLE_API_KEY` securely in the server environment before starting the app. No private key is included in this archive. Never expose it as a browser variable or commit it to source control. AI requests may incur usage charges.

Meal plans and shopping checkmarks are saved in the browser on the current device.

## Other commands

```sh
bun run test
bun run build
```

This archive contains the current project source and dependency lockfile. Installed dependencies, generated output, Git history, and private Lovable workspace metadata are excluded. TanStack regenerates its route tree when the development server starts. The original Lovable Vite configuration is retained.
