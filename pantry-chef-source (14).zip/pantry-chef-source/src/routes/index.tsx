import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ChefHat, Clock, Users, Loader2, Sparkles, CalendarDays, ShoppingBasket } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { generateRecipes, generateMealPlan, type Recipe, type MealPlan } from "@/lib/chef.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Pantry Chef — AI recipes, meal plans & shopping lists" },
      { name: "description", content: "Turn the ingredients you have into delicious recipes, weekly meal plans and smart shopping lists." },
      { property: "og:title", content: "Pantry Chef — your AI cooking assistant" },
      { property: "og:description", content: "Turn everyday ingredients into recipes, meal plans and shopping lists." },
    ],
  }),
  component: Index,
});

const errMsg = (e: unknown) => (e instanceof Error ? e.message : "Something went wrong. Please try again.");

function Index() {
  return (
    <main className="mx-auto min-h-screen max-w-2xl pb-16">
      <header className="bg-hero rounded-b-[2.5rem] px-6 pb-10 pt-12 text-primary-foreground shadow-soft">
        <div className="flex items-center gap-2 text-sm font-medium opacity-90">
          <ChefHat className="h-5 w-5" /> Pantry Chef
        </div>
        <h1 className="mt-4 text-4xl font-extrabold leading-tight">What's in your kitchen tonight?</h1>
        <p className="mt-3 opacity-90">Recipes from what you have, weekly plans, and a shopping list that writes itself.</p>
      </header>
      <Tabs defaultValue="recipes" className="px-4 pt-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="recipes">Recipes</TabsTrigger>
          <TabsTrigger value="plan">Meal plan</TabsTrigger>
          <TabsTrigger value="list">Shopping</TabsTrigger>
        </TabsList>
        <TabsContent value="recipes"><RecipesTab /></TabsContent>
        <TabsContent value="plan"><PlanTab /></TabsContent>
        <TabsContent value="list"><ShoppingTab /></TabsContent>
      </Tabs>
    </main>
  );
}

function RecipesTab() {
  const [ingredients, setIngredients] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const go = async () => {
    if (ingredients.trim().length < 2) { toast.error("Add a few ingredients first."); return; }
    setLoading(true);
    try {
      const r = await generateRecipes({ data: { ingredients, notes } });
      setRecipes(r.recipes);
    } catch (e) { toast.error(errMsg(e)); } finally { setLoading(false); }
  };
  return (
    <section className="space-y-4 pt-2">
      <Textarea rows={3} placeholder="e.g. eggs, spinach, half an onion, rice, feta" value={ingredients} onChange={(e) => setIngredients(e.target.value)} />
      <Input placeholder="Preferences (vegetarian, 20 min, spicy…)" value={notes} onChange={(e) => setNotes(e.target.value)} />
      <Button onClick={go} disabled={loading} className="w-full" size="lg">
        {loading ? <Loader2 className="animate-spin" /> : <Sparkles />} {loading ? "Cooking up ideas…" : "Create recipes"}
      </Button>
      {recipes.map((r) => (
        <article key={r.title} className="rounded-2xl border bg-card p-5 shadow-soft">
          <h2 className="text-2xl font-semibold">{r.title}</h2>
          <p className="mt-1 text-sm text-muted-foreground">{r.description}</p>
          <div className="mt-3 flex gap-4 text-sm text-secondary">
            <span className="flex items-center gap-1"><Clock className="h-4 w-4" />{r.time}</span>
            <span className="flex items-center gap-1"><Users className="h-4 w-4" />{r.servings}</span>
          </div>
          <h3 className="mt-4 font-semibold">Ingredients</h3>
          <ul className="mt-1 list-disc space-y-0.5 pl-5 text-sm">{r.ingredients.map((i) => <li key={i}>{i}</li>)}</ul>
          <h3 className="mt-4 font-semibold">Steps</h3>
          <ol className="mt-1 list-decimal space-y-1 pl-5 text-sm">{r.steps.map((s, i) => <li key={i}>{s}</li>)}</ol>
        </article>
      ))}
    </section>
  );
}

const PLAN_KEY = "pantry-chef-plan";
const CHECK_KEY = "pantry-chef-checked";

function usePlan() {
  const [plan, setPlanState] = useState<MealPlan | null>(null);
  useEffect(() => {
    const load = () => { const s = localStorage.getItem(PLAN_KEY); setPlanState(s ? JSON.parse(s) : null); };
    load();
    window.addEventListener("plan-updated", load);
    return () => window.removeEventListener("plan-updated", load);
  }, []);
  const setPlan = (p: MealPlan) => {
    localStorage.setItem(PLAN_KEY, JSON.stringify(p));
    localStorage.removeItem(CHECK_KEY);
    window.dispatchEvent(new Event("plan-updated"));
  };
  return { plan, setPlan };
}

function PlanTab() {
  const { plan, setPlan } = usePlan();
  const [diet, setDiet] = useState("");
  const [pantry, setPantry] = useState("");
  const [people, setPeople] = useState(2);
  const [loading, setLoading] = useState(false);
  const go = async () => {
    setLoading(true);
    try { setPlan(await generateMealPlan({ data: { diet, pantry, people } })); toast.success("Plan and shopping list ready!"); }
    catch (e) { toast.error(errMsg(e)); } finally { setLoading(false); }
  };
  return (
    <section className="space-y-4 pt-2">
      <Input placeholder="Diet & tastes (e.g. pescatarian, no mushrooms)" value={diet} onChange={(e) => setDiet(e.target.value)} />
      <Input placeholder="Already in your pantry" value={pantry} onChange={(e) => setPantry(e.target.value)} />
      <label className="flex items-center justify-between rounded-md border bg-card px-3 py-2 text-sm">
        People
        <Input type="number" min={1} max={12} value={people} onChange={(e) => setPeople(Math.min(12, Math.max(1, Number(e.target.value) || 1)))} className="w-20" />
      </label>
      <Button onClick={go} disabled={loading} className="w-full" size="lg">
        {loading ? <Loader2 className="animate-spin" /> : <CalendarDays />} {loading ? "Planning your week…" : "Plan my week"}
      </Button>
      {plan?.days.map((d) => (
        <div key={d.day} className="rounded-2xl border bg-card p-4">
          <h3 className="text-lg font-semibold text-primary">{d.day}</h3>
          <dl className="mt-2 grid grid-cols-[5.5rem_1fr] gap-y-1 text-sm">
            <dt className="text-muted-foreground">Breakfast</dt><dd>{d.breakfast}</dd>
            <dt className="text-muted-foreground">Lunch</dt><dd>{d.lunch}</dd>
            <dt className="text-muted-foreground">Dinner</dt><dd>{d.dinner}</dd>
          </dl>
        </div>
      ))}
    </section>
  );
}

function ShoppingTab() {
  const { plan } = usePlan();
  const [checked, setChecked] = useState<string[]>([]);
  useEffect(() => { setChecked(JSON.parse(localStorage.getItem(CHECK_KEY) || "[]")); }, [plan]);
  const toggle = (item: string) => {
    const next = checked.includes(item) ? checked.filter((i) => i !== item) : [...checked, item];
    setChecked(next);
    localStorage.setItem(CHECK_KEY, JSON.stringify(next));
  };
  if (!plan) return (
    <div className="mt-6 rounded-2xl border border-dashed p-8 text-center text-muted-foreground">
      <ShoppingBasket className="mx-auto mb-2 h-8 w-8" />Create a meal plan and your shopping list appears here.
    </div>
  );
  return (
    <section className="space-y-4 pt-2">
      {plan.shopping.map((c) => (
        <div key={c.category} className="rounded-2xl border bg-card p-4">
          <h3 className="mb-2 font-semibold text-secondary">{c.category}</h3>
          {c.items.map((i) => (
            <label key={i} className="flex items-center gap-3 py-1.5 text-sm">
              <Checkbox checked={checked.includes(i)} onCheckedChange={() => toggle(i)} />
              <span className={checked.includes(i) ? "text-muted-foreground line-through" : ""}>{i}</span>
            </label>
          ))}
        </div>
      ))}
    </section>
  );
}
