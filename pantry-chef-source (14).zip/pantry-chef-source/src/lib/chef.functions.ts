import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const recipeSchema = z.object({
  title: z.string(),
  description: z.string(),
  time: z.string(),
  servings: z.number(),
  ingredients: z.array(z.string()),
  steps: z.array(z.string()),
});
export type Recipe = z.infer<typeof recipeSchema>;

const planSchema = z.object({
  days: z.array(
    z.object({
      day: z.string(),
      breakfast: z.string(),
      lunch: z.string(),
      dinner: z.string(),
    }),
  ),
  shopping: z.array(z.object({ category: z.string(), items: z.array(z.string()) })),
});
export type MealPlan = z.infer<typeof planSchema>;

export const generateRecipes = createServerFn({ method: "POST" })
  .inputValidator(z.object({ ingredients: z.string().min(2).max(1000), notes: z.string().max(300) }))
  .handler(async ({ data }) => {
    const { generateJson } = await import("./ai.server");
    return generateJson(
      z.object({ recipes: z.array(recipeSchema) }),
      "You are Pantry Chef, a warm, practical home cook. Create exactly 3 distinct recipes that mainly use the user's ingredients (assume basic staples like salt, oil, pepper, water). Minimize food waste. Keep steps concise.",
      `Ingredients I have: ${data.ingredients}\nPreferences: ${data.notes || "none"}`,
    );
  });

export const generateMealPlan = createServerFn({ method: "POST" })
  .inputValidator(z.object({ diet: z.string().max(300), people: z.number().min(1).max(12), pantry: z.string().max(1000) }))
  .handler(async ({ data }) => {
    const { generateJson } = await import("./ai.server");
    return generateJson(
      planSchema,
      "You are Pantry Chef. Build a 7-day meal plan (Monday to Sunday) with short dish names, reusing ingredients across days to reduce waste. Then produce a consolidated shopping list grouped by store category with quantities, excluding items the user already has.",
      `Diet/preferences: ${data.diet || "none"}\nPeople: ${data.people}\nAlready in pantry: ${data.pantry || "nothing listed"}`,
    );
  });
