import { createOpenAI } from "@ai-sdk/openai";
import { streamText, Output } from "ai";
import type { z } from "zod";

const RUN_ID = "X-Lovable-AIG-Run-ID";

export async function generateJson<T extends z.ZodType>(
  schema: T,
  instructions: string,
  prompt: string,
): Promise<z.infer<T>> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new Error("AI is not configured.");
  let runId: string | undefined;
  const provider = createOpenAI({
    baseURL: "https://ai.gateway.lovable.dev/v1",
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: async (input, init) => {
      const headers = new Headers(init?.headers);
      if (runId) headers.set(RUN_ID, runId);
      const res = await fetch(input, { ...init, headers });
      runId ??= res.headers.get(RUN_ID) ?? undefined;
      if (res.status === 402) throw new Error("AI credits are used up. Please add credits to continue.");
      if (res.status === 429) throw new Error("Too many requests right now. Please try again in a moment.");
      return res;
    },
  });
  const result = streamText({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- nested @ai-sdk/provider version skew
    model: provider.responses("openai/gpt-6-astra") as any,
    instructions,
    prompt,
    output: Output.object({ schema }),
    providerOptions: {
      openai: {
        forceReasoning: true,
        reasoningEffort: "low",
        reasoningSummary: "auto",
        store: false,
        include: ["reasoning.encrypted_content"],
      },
    },
  });
  return (await result.output) as z.infer<T>;
}
